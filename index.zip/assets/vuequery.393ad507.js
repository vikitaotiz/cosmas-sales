import{V as r}from"./index.6a80c9ab.js";import"./index.2bde107a.js";var o=({app:e})=>{e.use(r)};export{o as default};
