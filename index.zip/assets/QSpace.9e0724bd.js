import{h as e,bA as a}from"./index.2bde107a.js";const p=e("div",{class:"q-space"});var c=a({name:"QSpace",setup(){return()=>p}});export{c as Q};
